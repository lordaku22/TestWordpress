<?php

namespace StaticHTMLOutput;

use Exception;

class StaticHTMLOutputException extends Exception {
}

